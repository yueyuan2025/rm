# -*- coding: utf-8 -*-
"""
RoboMaster 装甲板综合感知程序
功能：YOLO 检测 + 数字识别 + 测距 + 跟踪平滑 + 串口发送
支持：树莓派 / Windows / Linux
作者：整合自 rm_yolo.py, rm_final.py, rm_yolo_perception_pc.py, Perception.py
"""

import cv2
import numpy as np
import time
import platform
import pytesseract
from ultralytics import YOLO

# ------------------------- 平台检测 -------------------------
IS_RASPBERRY = platform.system() == "Linux" and "raspberry" in platform.uname()[4].lower()
print("🖥️ 树莓派模式" if IS_RASPBERRY else "🖥️ 电脑模式")

# ------------------------- 全局配置 -------------------------
# 模型路径（请根据实际位置修改）
MODEL_PATH = "armor_best.pt"

# 摄像头配置
CAM_ID = 0                     # 摄像头索引
FRAME_WIDTH = 640
FRAME_HEIGHT = 480

# YOLO 推理参数
CONF_THRES = 0.55
IOU_THRES = 0.45
IMG_SIZE = 416                 # 树莓派建议用小尺寸

# 测距参数（装甲板实际高度 cm，相机焦距需标定）
ARMOR_HEIGHT_CM = 5.5
FOCAL_LENGTH = 750             # 根据实际标定调整

# 数字识别白名单
OCR_CONFIG = r'--oem 3 --psm 10 -c tessedit_char_whitelist=12345'

# 跟踪平滑系数（0~1，值越小越平滑）
SMOOTH_FACTOR = 0.7

# 串口配置
SERIAL_ENABLE = False          # 是否启用串口
if IS_RASPBERRY:
    SERIAL_PORT = "/dev/ttyUSB0"
else:
    SERIAL_PORT = "COM3"       # Windows 串口号
BAUD_RATE = 115200

# ------------------------- 初始化 -------------------------
# 加载 YOLO 模型
model = YOLO(MODEL_PATH)

# 打开摄像头
cap = cv2.VideoCapture(CAM_ID)
cap.set(cv2.CAP_PROP_FRAME_WIDTH, FRAME_WIDTH)
cap.set(cv2.CAP_PROP_FRAME_HEIGHT, FRAME_HEIGHT)
if not cap.isOpened():
    print("❌ 摄像头打开失败")
    exit()

# 串口初始化
ser = None
if SERIAL_ENABLE:
    try:
        import serial
        ser = serial.Serial(SERIAL_PORT, BAUD_RATE, timeout=0.01)
        print("✅ 串口已打开")
    except Exception as e:
        print(f"⚠️ 串口打开失败：{e}")

# 跟踪历史（存储最近目标：cx, cy, cls, num）
last_targets = []

# FPS 历史
fps_history = []

# ------------------------- 辅助函数 -------------------------
def calc_distance(pixel_height):
    """根据像素高度估算距离（cm）"""
    if pixel_height < 10:
        return 0.0
    return round((ARMOR_HEIGHT_CM * FOCAL_LENGTH) / pixel_height, 2)

def recognize_number(roi):
    """从装甲板 ROI 中识别数字"""
    if roi.size == 0:
        return ""
    gray = cv2.cvtColor(roi, cv2.COLOR_BGR2GRAY)
    _, th = cv2.threshold(gray, 0, 255, cv2.THRESH_BINARY + cv2.THRESH_OTSU)
    num = pytesseract.image_to_string(th, config=OCR_CONFIG).strip()
    return num if num in "12345" else ""

def extract_number_from_box(frame, box):
    """从 YOLO 检测框中提取数字 ROI"""
    x1, y1, x2, y2 = box
    cx = (x1 + x2) // 2
    cy = (y1 + y2) // 2
    w = x2 - x1
    h = y2 - y1

    # 根据装甲板比例裁剪数字区域（参考 rm_yolo.py）
    roi_x1 = int(cx - w * 0.35)
    roi_y1 = int(cy - h * 0.1)
    roi_x2 = int(cx + w * 0.35)
    roi_y2 = int(cy + h * 0.7)

    # 边界裁剪
    h, w_frame = frame.shape[:2]
    roi_x1 = max(0, roi_x1)
    roi_y1 = max(0, roi_y1)
    roi_x2 = min(w_frame, roi_x2)
    roi_y2 = min(h, roi_y2)

    roi = frame[roi_y1:roi_y2, roi_x1:roi_x2]
    return recognize_number(roi)

def smooth_targets(current_targets):
    """对当前目标进行位置平滑（防抖）"""
    global last_targets
    smoothed = []
    for curr in current_targets:
        cx_c, cy_c, cls_c, num_c = curr
        best = None
        min_dist = 1e9
        for lst in last_targets:
            cx_l, cy_l, cls_l, _ = lst
            if cls_c != cls_l:
                continue
            dist = (cx_c - cx_l) ** 2 + (cy_c - cy_l) ** 2
            if dist < 3600 and dist < min_dist:   # 60 像素内匹配
                min_dist = dist
                best = lst
        if best:
            cx_s = SMOOTH_FACTOR * cx_c + (1 - SMOOTH_FACTOR) * best[0]
            cy_s = SMOOTH_FACTOR * cy_c + (1 - SMOOTH_FACTOR) * best[1]
            smoothed.append((cx_s, cy_s, cls_c, num_c))
        else:
            smoothed.append(curr)
    last_targets = smoothed.copy()
    return smoothed

# ------------------------- 主循环 -------------------------
print("🚀 RoboMaster 装甲板感知启动")

while True:
    t_start = time.time()
    ret, frame = cap.read()
    if not ret:
        break

    # ----- 1. YOLO 推理 -----
    results = model(frame, imgsz=IMG_SIZE, conf=CONF_THRES, iou=IOU_THRES, half=IS_RASPBERRY)

    # ----- 2. 解析检测结果 -----
    current_targets = []   # 存储 (cx, cy, cls, num)
    for r in results:
        for box in r.boxes:
            x1, y1, x2, y2 = map(int, box.xyxy[0])
            cls = int(box.cls[0])      # 0:红色, 1:蓝色（根据自己模型类别）
            conf = float(box.conf[0])

            cx = (x1 + x2) // 2
            cy = (y1 + y2) // 2
            height = y2 - y1

            # 距离估算
            distance = calc_distance(height)

            # 数字识别
            num = extract_number_from_box(frame, (x1, y1, x2, y2))

            current_targets.append((cx, cy, cls, num, distance, conf, (x1, y1, x2, y2)))

    # ----- 3. 平滑处理（只对位置和类别）-----
    pos_targets = [(cx, cy, cls, num) for (cx, cy, cls, num, _, _, _) in current_targets]
    smoothed = smooth_targets(pos_targets)
    # 将平滑后的坐标写回
    for i, (cx_s, cy_s, cls_s, num_s) in enumerate(smoothed):
        if i < len(current_targets):
            # 只替换坐标和数字，其他信息保留
            orig = current_targets[i]
            current_targets[i] = (cx_s, cy_s, cls_s, num_s, orig[4], orig[5], orig[6])

    # ----- 4. 选择发送目标（最近距离）-----
    if current_targets:
        # 按距离排序（最近优先）
        current_targets.sort(key=lambda t: t[4])
        best = current_targets[0]   # 最近目标
        cx, cy, cls, num, dist, conf, (x1, y1, x2, y2) = best

        # 定义颜色和字符串（供串口和绘制使用）
        color_str = "RED" if cls == 0 else "BLUE"
        color = (0, 0, 255) if cls == 0 else (255, 0, 0)

        # 串口发送
        if SERIAL_ENABLE and ser:
            data = f"{color_str},{cx},{cy},{dist:.2f},{num}\n"
            try:
                ser.write(data.encode())
                print(f"📤 发送：{data.strip()}")
            except Exception as e:
                print(f"串口发送失败：{e}")

        # 在画面上绘制最佳目标信息（特殊颜色）
        cv2.rectangle(frame, (x1, y1), (x2, y2), color, 3)
        cv2.circle(frame, (int(cx), int(cy)), 7, color, -1)
        cv2.putText(frame, f"{color_str} {dist:.1f}cm", (x1, y1-10),
                    cv2.FONT_HERSHEY_SIMPLEX, 0.6, color, 2)
        if num:
            cv2.putText(frame, f"NUM:{num}", (x1, y2+20),
                        cv2.FONT_HERSHEY_SIMPLEX, 0.5, (0,255,255), 2)

    # ----- 5. 绘制所有检测框（可选）-----
    for (cx, cy, cls, num, dist, conf, (x1, y1, x2, y2)) in current_targets:
        # 普通检测框颜色
        color = (0, 0, 255) if cls == 0 else (255, 0, 0)
        cv2.rectangle(frame, (x1, y1), (x2, y2), color, 1)
        cv2.putText(frame, f"{conf:.2f}", (x1, y1-5),
                    cv2.FONT_HERSHEY_SIMPLEX, 0.4, (255,255,255), 1)

    # ----- 6. 显示 FPS -----
    fps = 1.0 / (time.time() - t_start + 1e-6)
    fps_history.append(fps)
    if len(fps_history) > 10:
        fps_history.pop(0)
    avg_fps = np.mean(fps_history)
    cv2.putText(frame, f"FPS: {avg_fps:.1f}", (10, 30),
                cv2.FONT_HERSHEY_SIMPLEX, 0.7, (0,255,0), 2)

    # ----- 7. 显示画面 -----
    cv2.imshow("RM Armor Perception", frame)
    if cv2.waitKey(1) & 0xFF == ord('q'):
        break

# 释放资源
if ser:
    ser.close()
cap.release()
cv2.destroyAllWindows()
