#include "CameraApi.h"
#include <opencv2/opencv.hpp>
#include <opencv2/dnn.hpp>
#include <iostream>
#include <vector>
#include <string>

using namespace cv;

const std::string MODEL_PATH = "armor_best.onnx";
const int INPUT_WIDTH = 416;
const int INPUT_HEIGHT = 416;

cv::dnn::Net initYOLO() {
    cv::dnn::Net net = cv::dnn::readNetFromONNX(MODEL_PATH);
    if (net.empty()) {
        std::cerr << "错误：无法加载 ONNX 模型，请检查文件路径：" << MODEL_PATH << std::endl;
    }
    // 明确指定后端为 CPU（避免自动选择导致问题）
    net.setPreferableBackend(cv::dnn::DNN_BACKEND_OPENCV);
    net.setPreferableTarget(cv::dnn::DNN_TARGET_CPU);
    return net;
}

Mat preprocess(const Mat& frame) {
    Mat blob;
    cv::dnn::blobFromImage(frame, blob, 1.0 / 255.0, Size(INPUT_WIDTH, INPUT_HEIGHT), Scalar(), true, false);
    return blob;
}

int main() {
    // ---------- 相机初始化（与之前相同，已验证） ----------
    int iStatus;
    tSdkCameraDevInfo tCameraEnumList[64];
    int iCameraCounts = 64;
    CameraSdkInit(1);
    CameraEnumerateDevice(tCameraEnumList, &iCameraCounts);
    std::cout << "枚举到相机数量: " << iCameraCounts << std::endl;
    if (iCameraCounts == 0) return -1;

    int hCamera;
    iStatus = CameraInit(&tCameraEnumList[0], -1, -1, &hCamera);
    if (iStatus != CAMERA_STATUS_SUCCESS) {
        std::cerr << "相机打开失败: " << iStatus << std::endl;
        return -1;
    }
    std::cout << "相机打开成功" << std::endl;
    CameraPlay(hCamera);
    std::cout << "开始采集" << std::endl;

    // ---------- YOLO 初始化 ----------
    cv::dnn::Net net = initYOLO();
    if (net.empty()) {
        std::cerr << "YOLO 模型加载失败，退出程序" << std::endl;
        CameraStop(hCamera);
        CameraUnInit(hCamera);
        return -1;
    }
    std::cout << "YOLO 模型加载成功" << std::endl;

    // 图像缓冲区
    tSdkFrameHead frameHead;
    unsigned char* pRawBuffer = nullptr;
    unsigned char* pRgbBuffer = nullptr;
    int rgbSize = 0;

    while (true) {
        // 获取图像（与之前相同）
        iStatus = CameraGetImageBuffer(hCamera, &frameHead, &pRawBuffer, 1000);
        if (iStatus != CAMERA_STATUS_SUCCESS) continue;
        if (frameHead.iWidth <= 0 || frameHead.iHeight <= 0) {
            CameraReleaseImageBuffer(hCamera, pRawBuffer);
            continue;
        }

        int requiredSize = frameHead.iWidth * frameHead.iHeight * 3;
        if (rgbSize < requiredSize) {
            delete[] pRgbBuffer;
            pRgbBuffer = new unsigned char[requiredSize];
            rgbSize = requiredSize;
        }

        iStatus = CameraImageProcess(hCamera, pRawBuffer, pRgbBuffer, &frameHead);
        CameraReleaseImageBuffer(hCamera, pRawBuffer);
        if (iStatus != CAMERA_STATUS_SUCCESS) continue;

        Mat imgRGB(frameHead.iHeight, frameHead.iWidth, CV_8UC3, pRgbBuffer);
        Mat imgBGR;
        cvtColor(imgRGB, imgBGR, COLOR_RGB2BGR);

        // ---------- YOLO 推理（仅打印输出形状） ----------
        try {
            Mat blob = preprocess(imgBGR);
            net.setInput(blob);
            std::vector<Mat> outputs;
            net.forward(outputs, net.getUnconnectedOutLayersNames());

            if (outputs.empty()) {
                std::cerr << "模型没有输出层" << std::endl;
            } else {
                // 打印每个输出的维度
                for (size_t i = 0; i < outputs.size(); ++i) {
                    std::cout << "输出 " << i << " 维度: " << outputs[i].dims << " 尺寸: ";
                    for (int j = 0; j < outputs[i].dims; ++j) {
                        std::cout << outputs[i].size[j] << " ";
                    }
                    std::cout << std::endl;
                }
            }
        } catch (const cv::Exception& e) {
            std::cerr << "OpenCV 异常: " << e.what() << std::endl;
        }

        // 只显示原始图像，不进行检测框绘制
        imshow("RM Perception", imgBGR);
        if (waitKey(1) == 'q') break;
    }

    delete[] pRgbBuffer;
    CameraStop(hCamera);
    CameraUnInit(hCamera);
    destroyAllWindows();
    return 0;
}
