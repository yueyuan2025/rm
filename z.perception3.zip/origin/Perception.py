# -*- coding: utf-8 -*-
from ultralytics import YOLO
import cv2
import platform

# ==================== 自动识别：电脑 / 树莓派 ====================
IS_RASPBERRY = platform.system() == "Linux" and "raspberry" in platform.uname()[4].lower()

# ==================== 配置 ====================
MODEL_PATH = "armor_best.pt"
CONFIDENCE = 0.55
IMG_SIZE = 416

# 摄像头
if IS_RASPBERRY:
    CAM_ID = 0
else:
    CAM_ID = 0

# 串口
BAUD = 115200
SERIAL_PORT = "/dev/ttyUSB0" if IS_RASPBERRY else "COM3"

# ==================== 加载模型 ====================
model = YOLO(MODEL_PATH)
cap = cv2.VideoCapture(CAM_ID)
cap.set(cv2.CAP_PROP_FRAME_WIDTH, 640)
cap.set(cv2.CAP_PROP_FRAME_HEIGHT, 480)

# ==================== 主程序 ====================
print("🚀 RoboMaster 装甲板感知启动")
print("🖥️ 树莓派模式" if IS_RASPBERRY else "🖥️ 电脑模式")

while True:
    ret, frame = cap.read()
    if not ret: break

    # YOLO 推理
    results = model(frame, imgsz=IMG_SIZE, conf=CONFIDENCE, half=IS_RASPBERRY)

    # 解析目标
    targets = []
    for r in results:
        for box in r.boxes:
            x1, y1, x2, y2 = map(int, box.xyxy[0])
            cls = int(box.cls[0])
            cx = (x1 + x2) // 2
            cy = (y1 + y2) // 2
            targets.append((cx, cy, cls))

            # 绘制
            color = (0,0,255) if cls == 0 else (255,0,0)
            cv2.rectangle(frame, (x1,y1), (x2,y2), color, 2)

    # 显示画面
    cv2.imshow("RM Armor Detection", frame)
    if cv2.waitKey(1) & 0xFF == ord('q'): break

cap.release()
cv2.destroyAllWindows()

