# -*- coding: utf-8 -*-
from ultralytics import YOLO
import cv2
import numpy as np
import serial
import platform

# ======================================
# 【关键：自动识别电脑 / 树莓派】
# ======================================
IS_PI = platform.system() == "Linux" and "raspberry" in platform.uname()[4].lower()

# ==================== 模型与摄像头配置 ====================
MODEL_PATH = "armor_best.pt"  # 装甲板模型

# 摄像头配置
if IS_PI:
    CAM_ID = 0  # 树莓派 CSI 相机 / USB 相机
else:
    CAM_ID = 0  # 电脑摄像头

IMG_SIZE = 416  # 小尺寸，树莓派跑得更快
CONF_THRES = 0.6  # 置信度
IOU_THRES = 0.45

# ==================== 串口配置 ====================
BAUD_RATE = 115200
if IS_PI:
    SERIAL_PORT = "/dev/ttyUSB0"  # 树莓派 USB 转串口
else:
    SERIAL_PORT = "COM3"  # 电脑串口

# ==================== 测距参数 ====================
ARMOR_HEIGHT = 5.5
FOCAL = 750

# ==================== 初始化 ====================
model = YOLO(MODEL_PATH)
cap = cv2.VideoCapture(CAM_ID)
cap.set(cv2.CAP_PROP_FRAME_WIDTH, 640)
cap.set(cv2.CAP_PROP_FRAME_HEIGHT, 480)

# 串口
ser = None
try:
    ser = serial.Serial(SERIAL_PORT, BAUD_RATE, timeout=0.01)
    print("✅ 串口连接成功")
except:
    print("⚠️  串口未连接")

# ==================== 测距函数 ====================
def calc_distance(pixel_h):
    if pixel_h < 10:
        return 0
    return round((ARMOR_HEIGHT * FOCAL) / pixel_h, 2)

# ==================== 主循环 ====================
if __name__ == "__main__":
    print("🚀 RoboMaster 装甲板感知启动")
    print("🖥️ 树莓派" if IS_PI else "🖥️ 电脑模式")

    while True:
        ret, frame = cap.read()
        if not ret:
            break

        # YOLO 推理
        results = model(frame, imgsz=IMG_SIZE, conf=CONF_THRES, iou=IOU_THRES)

        targets = []
        for r in results:
            for box in r.boxes:
                x1, y1, x2, y2 = map(int, box.xyxy[0])
                cls = int(box.cls[0])
                conf = round(float(box.conf[0]), 2)

                cx = (x1 + x2) // 2
                cy = (y1 + y2) // 2
                h = y2 - y1
                dis = calc_distance(h)
                targets.append((cx, cy, dis, conf, cls))

                # 绘制
                color = (0, 0, 255) if cls == 0 else (255, 0, 0)
                cv2.rectangle(frame, (x1, y1), (x2, y2), color, 2)
                cv2.circle(frame, (cx, cy), 4, (0, 255, 0), -1)
                cv2.putText(frame, f"{conf} {dis}cm", (x1, y1 - 10),
                            cv2.FONT_HERSHEY_SIMPLEX, 0.5, color, 1)

        # 发送最近目标
        if targets:
            targets.sort(key=lambda x: x[2])
            cx, cy, dis, conf, cls = targets[0]
            print(f"🎯 目标 X:{cx} Y:{cy} 距离:{dis}cm")

            if ser:
                data = f"{cx},{cy},{dis},{cls};\n"
                ser.write(data.encode())

        # 显示画面
        cv2.imshow("RM Armor Detection", frame)
        if cv2.waitKey(1) & 0xFF == ord('q'):
            break

    cap.release()
    cv2.destroyAllWindows()
    if ser:
        ser.close()

