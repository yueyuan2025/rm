import cv2
import numpy as np
from ultralytics import YOLO
import time
import pytesseract

# ===================== 全局配置 =====================
# 模型路径（你训练的模型，以后替换 armor_best.pt 即可）
model = YOLO("runs/detect/train2/weights/best.pt")

# 颜色阈值
RED_LOWER = np.array([0, 130, 130])
RED_UPPER = np.array([10, 255, 255])
BLUE_LOWER = np.array([100, 130, 130])
BLUE_UPPER = np.array([124, 255, 255])

# 目标跟踪防抖
last_targets = []
fps_history = []

# 串口配置（给STM32/云台）
SERIAL_ENABLE = False       # 要使用串口请改为 True
SERIAL_PORT = "/dev/ttyUSB0"
BAUD_RATE = 115200
ser = None

if SERIAL_ENABLE:
    import serial
    try:
        ser = serial.Serial(SERIAL_PORT, BAUD_RATE, timeout=0.01)
        print("✅ 串口已打开")
    except:
        print("❌ 串口打开失败")

# 摄像头
cap = cv2.VideoCapture(0)
cap.set(cv2.CAP_PROP_FRAME_WIDTH, 640)
cap.set(cv2.CAP_PROP_FRAME_HEIGHT, 480)

# OCR 只识别数字
OCR_CONFIG = r'--oem 3 --psm 10 -c tessedit_char_whitelist=12345'

# ===================== 数字识别 =====================
def recognize_armor_number(frame, x1, y1, x2, y2):
    cx = (x1 + x2) / 2
    cy = (y1 + y2) / 2
    w = abs(x1 - x2)
    h = max(abs(y1 - y2), w * 0.6)

    x_min = int(cx - w * 0.35)
    y_min = int(cy - h * 0.1)
    x_max = int(cx + w * 0.35)
    y_max = int(cy + h * 0.7)

    h, ww = frame.shape[:2]
    x_min = max(0, x_min)
    y_min = max(0, y_min)
    x_max = min(ww, x_max)
    y_max = min(h, y_max)

    roi = frame[y_min:y_max, x_min:x_max]
    if roi.size == 0:
        return ""

    gray = cv2.cvtColor(roi, cv2.COLOR_BGR2GRAY)
    _, th = cv2.threshold(gray, 0, 255, cv2.THRESH_BINARY + cv2.THRESH_OTSU)
    num = pytesseract.image_to_string(th, config=OCR_CONFIG).strip()
    return num if num in "12345" else ""

# ===================== 装甲板检测主函数 =====================
def detect_armor(frame, mask, color, label):
    global last_targets
    current_targets = []
    contours, _ = cv2.findContours(mask, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)
    light_bars = []

    # 灯条严格筛选
    for cnt in contours:
        area = cv2.contourArea(cnt)
        if not (100 < area < 3500):
            continue
        rect = cv2.minAreaRect(cnt)
        (x, y), (w, h), ang = rect
        if min(w, h) < 2:
            continue
        ratio = max(w, h) / min(w, h)
        if not (2.2 < ratio < 9):
            continue
        if abs(ang) > 32 and abs(ang - 180) > 32:
            continue
        light_bars.append(rect)

    # 灯条配对
    if len(light_bars) >= 2:
        light_bars.sort(key=lambda r: r[0][0])
        for i in range(len(light_bars)):
            for j in range(i + 1, len(light_bars)):
                b1 = light_bars[i]
                b2 = light_bars[j]
                (x1, y1), (w1, h1), a1 = b1
                (x2, y2), (w2, h2), a2 = b2

                len1 = max(w1, h1)
                len2 = max(w2, h2)
                dy = abs(y1 - y2)
                dx = abs(x1 - x2)
                da = abs(a1 - a2)

                # 赛场真实约束
                if abs(len1 - len2) > 28: continue
                if dy > 40: continue
                if dx > 240: continue
                if da > 15: continue

                cx = (x1 + x2) / 2
                cy = (y1 + y2) / 2
                num = recognize_armor_number(frame, x1, y1, x2, y2)
                current_targets.append((cx, cy, label, num))

    # 跟踪平滑
    smoothed = []
    for curr in current_targets:
        cx_c, cy_c, lab_c, num_c = curr
        best = None
        min_dist = 1e9
        for lst in last_targets:
            cx_l, cy_l, lab_l, _ = lst
            if lab_c != lab_l: continue
            dist = (cx_c - cx_l)**2 + (cy_c - cy_l)**2
            if dist < 3600 and dist < min_dist:
                min_dist = dist
                best = lst
        if best:
            cx_s = 0.7 * cx_c + 0.3 * best[0]
            cy_s = 0.7 * cy_c + 0.3 * best[1]
            smoothed.append((cx_s, cy_s, lab_c, num_c))
        else:
            smoothed.append(curr)
    last_targets = smoothed.copy()

    # 绘制
    for (cx, cy, lab, num) in smoothed:
        # 中心点十字瞄准线
        cv2.drawMarker(frame, (int(cx), int(cy)), color, cv2.MARKER_CROSS, 20, 2)
        cv2.circle(frame, (int(cx), int(cy)), 7, color, -1)
        cv2.putText(frame, lab, (int(cx) - 38, int(cy) - 25),
                    cv2.FONT_HERSHEY_SIMPLEX, 0.7, color, 2)
        if num:
            cv2.putText(frame, f"NUM:{num}", (int(cx)-25, int(cy)+25),
                        cv2.FONT_HERSHEY_SIMPLEX, 0.6, (0,255,255), 2)

        # 串口发送坐标给云台
        if SERIAL_ENABLE and ser:
            data = f"ARMOR,{lab},{int(cx)},{int(cy)},{num}\n"
            try:
                ser.write(data.encode())
            except:
                pass
    return frame

# ===================== 主循环 =====================
while True:
    t_start = time.time()
    ret, frame = cap.read()
    if not ret:
        break

    # YOLO检测
    results = model(frame, conf=0.58)
    frame = results[0].plot()

    # 灯条预处理
    blur = cv2.GaussianBlur(frame, (5, 5), 0)
    hsv = cv2.cvtColor(blur, cv2.COLOR_BGR2GRAY)
    hsv = cv2.cvtColor(blur, cv2.COLOR_BGR2HSV)
    kernel = cv2.getStructuringElement(cv2.MORPH_RECT, (3, 3))

    mask_r = cv2.inRange(hsv, RED_LOWER, RED_UPPER)
    mask_b = cv2.inRange(hsv, BLUE_LOWER, BLUE_UPPER)
    mask_r = cv2.morphologyEx(mask_r, cv2.MORPH_OPEN, kernel)
    mask_b = cv2.morphologyEx(mask_b, cv2.MORPH_OPEN, kernel)

    # 识别装甲板
    frame = detect_armor(frame, mask_r, (0, 0, 255), "RED_ARMOR")
    frame = detect_armor(frame, mask_b, (255, 0, 0), "BLUE_ARMOR")

    # FPS计算
    fps = 1.0 / (time.time() - t_start + 1e-6)
    fps_history.append(fps)
    if len(fps_history) > 10:
        fps_history.pop(0)
    avg_fps = np.mean(fps_history)
    cv2.putText(frame, f"FPS: {avg_fps:.1f}", (10, 30),
                cv2.FONT_HERSHEY_SIMPLEX, 0.7, (0,255,0), 2)

    cv2.imshow("RM Vision Pro 2026", frame)
    if cv2.waitKey(1) & 0xFF == ord('q'):
        break

if SERIAL_ENABLE and ser:
    ser.close()
cap.release()
cv2.destroyAllWindows()

