import cv2
import numpy as np
from ultralytics import YOLO

# 加载 YOLO 模型
model = YOLO("armor_best.pt")

# ===================== 切换到迈德威视摄像头（先试 0，不行再试 2） =====================
cap = cv2.VideoCapture(0)  # 先试 0，不行改成 2

# 迈德威视必须设置的参数
cap.set(cv2.CAP_PROP_FOURCC, cv2.VideoWriter_fourcc(*"MJPG"))
cap.set(cv2.CAP_PROP_FRAME_WIDTH, 1280)
cap.set(cv2.CAP_PROP_FRAME_HEIGHT, 720)
cap.set(cv2.CAP_PROP_FPS, 30)

if not cap.isOpened():
    print("摄像头打开失败！尝试更换索引 0 / 2")
    exit()

# ✅ 窗口创建移到这里，只执行一次
cv2.namedWindow("RM 视觉检测", cv2.WINDOW_NORMAL)
cv2.resizeWindow("RM 视觉检测", 1280, 720)

print("✅ 摄像头启动成功！按 Q 退出")

# ===================== 主循环 =====================
while True:
    ret, frame = cap.read()
    if not ret:
        break

    # YOLO 检测
    results = model(frame, conf=0.5, imgsz=(720, 1280))
    frame = results[0].plot()

    # 只显示，不再创建窗口
    cv2.imshow("RM 视觉检测", frame)

    if cv2.waitKey(1) & 0xFF == ord('q'):
        break

cap.release()
cv2.destroyAllWindows()
